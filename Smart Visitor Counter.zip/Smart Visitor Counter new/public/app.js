
const apiBaseUrl = (
  window.DASHBOARD_CONFIG &&
  window.DASHBOARD_CONFIG.apiBaseUrl || ""
).replace(/\/$/, "");

// Sample records are shown only if the API is not configured
// or cannot be reached.
const sampleRecords = [
  { device: "SmartVisitorCounter", visitor_count: 1, category: "Children", timestamp: Date.now() - 3600000 },
  { device: "SmartVisitorCounter", visitor_count: 2, category: "Men", timestamp: Date.now() - 3000000 },
  { device: "SmartVisitorCounter", visitor_count: 3, category: "Women", timestamp: Date.now() - 2400000 },
  { device: "SmartVisitorCounter", visitor_count: 4, category: "Children", timestamp: Date.now() - 1800000 },
  { device: "SmartVisitorCounter", visitor_count: 5, category: "Men", timestamp: Date.now() - 900000 },
  { device: "SmartVisitorCounter", visitor_count: 6, category: "Women", timestamp: Date.now() - 600000 }
];

let historyChart;
let hourChart;
let categoryChart;

// Convert timestamp into JavaScript Date.
// Supports both milliseconds and seconds.
function dateValue(value) {
  const n = Number(value);
  const d = new Date(n < 1e12 ? n * 1000 : n);

  return Number.isNaN(d.getTime()) ? null : d;
}

// Standardize category names
function normalizeCategory(value) {
  const category = String(value || "").trim().toLowerCase();

  if (["children", "child", "kids"].includes(category)) {
    return "Children";
  }

  if (["men", "man", "male"].includes(category)) {
    return "Men";
  }

  if (["women", "woman", "female"].includes(category)) {
    return "Women";
  }

  return "Uncategorized";
}

// Read records returned by AWS API
function normalizeRecords(payload) {
  const rows = Array.isArray(payload)
    ? payload
    : Array.isArray(payload.items)
      ? payload.items
      : Array.isArray(payload.records)
        ? payload.records
        : payload.Items || [];

  return rows.map(r => ({
    device: r.device || r.Device || "SmartVisitorCounter",

    visitor_count: Number(
      r.visitor_count ??
      r.visitorCount ??
      r.count ??
      0
    ),

    category: normalizeCategory(
      r.category ??
      r.Category ??
      r.visitor_category
    ),

    timestamp: Number(
      r.timestamp ??
      r.Timestamp ??
      0
    )
  }))
  .filter(r =>
    Number.isFinite(r.visitor_count) &&
    Number.isFinite(r.timestamp)
  )
  .sort((a, b) => a.timestamp - b.timestamp);
}

// Calculate category totals.
// Each categorized record represents one confirmed visitor.
function calculateCategoryTotals(records) {
  const totals = {
    Children: 0,
    Men: 0,
    Women: 0
  };

  records.forEach(record => {
    if (Object.prototype.hasOwnProperty.call(
      totals,
      record.category
    )) {
      totals[record.category]++;
    }
  });

  return totals;
}

// Draw all three graphs
function drawCharts(records) {

  const recent = records.slice(-20);

  const labels = recent.map(record => {
    const d = dateValue(record.timestamp);

    return d
      ? d.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit"
        })
      : "—";
  });

  const commonOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      }
    }
  };

  // 1. Visitor history line graph
  if (historyChart) {
    historyChart.destroy();
  }

  historyChart = new Chart(
    document.getElementById("historyChart"),
    {
      type: "line",

      data: {
        labels: labels,

        datasets: [{
          label: "Visitor count",
          data: recent.map(r => r.visitor_count),

          borderColor: "#315efb",
          backgroundColor: "rgba(49,94,251,.12)",

          fill: true,
          tension: 0.3,
          pointRadius: 3
        }]
      },

      options: {
        ...commonOptions,

        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              precision: 0
            }
          },

          x: {
            grid: {
              display: false
            }
          }
        }
      }
    }
  );

  // 2. Readings by hour
  const today = new Date();
  const hourly = Array(24).fill(0);

  records.forEach(record => {
    const d = dateValue(record.timestamp);

    if (
      d &&
      d.toDateString() === today.toDateString()
    ) {
      hourly[d.getHours()]++;
    }
  });

  if (hourChart) {
    hourChart.destroy();
  }

  hourChart = new Chart(
    document.getElementById("hourChart"),
    {
      type: "bar",

      data: {
        labels: hourly.map((_, i) =>
          String(i).padStart(2, "0") + ":00"
        ),

        datasets: [{
          label: "Readings",
          data: hourly,
          backgroundColor: "#7c91f8",
          borderRadius: 4
        }]
      },

      options: {
        ...commonOptions,

        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              precision: 0
            }
          },

          x: {
            grid: {
              display: false
            },

            ticks: {
              maxTicksLimit: 8
            }
          }
        }
      }
    }
  );

  // 3. New category comparison bar graph
  const totals = calculateCategoryTotals(records);

  if (categoryChart) {
    categoryChart.destroy();
  }

  categoryChart = new Chart(
    document.getElementById("categoryChart"),
    {
      type: "bar",

      data: {
        labels: [
          "Children",
          "Men",
          "Women"
        ],

        datasets: [{
          label: "Visitors",

          data: [
            totals.Children,
            totals.Men,
            totals.Women
          ],

          backgroundColor: [
            "#16a36a",
            "#d98a19",
            "#8b5cf6"
          ],

          borderRadius: 7,
          maxBarThickness: 90
        }]
      },

      options: {
        ...commonOptions,

        scales: {
          y: {
            beginAtZero: true,

            ticks: {
              precision: 0
            }
          },

          x: {
            grid: {
              display: false
            }
          }
        },

        plugins: {
          legend: {
            display: false
          },

          tooltip: {
            callbacks: {
              label: context =>
                ` ${context.parsed.y} visitors`
            }
          }
        }
      }
    }
  );
}

// Display dashboard information
function render(records, live) {

  const latest = records[records.length - 1];

  const todayRows = records.filter(record => {
    const d = dateValue(record.timestamp);

    return d &&
      d.toDateString() === new Date().toDateString();
  });

  const totals = calculateCategoryTotals(records);

  // Existing dashboard cards
  document.getElementById("latestCount").textContent =
    latest ? latest.visitor_count : "0";

  document.getElementById("totalRecords").textContent =
    records.length;

  document.getElementById("todayCount").textContent =
    todayRows.length
      ? todayRows[todayRows.length - 1].visitor_count
      : "0";

  document.getElementById("deviceName").textContent =
    latest ? latest.device : "SmartVisitorCounter";

  document.getElementById("deviceStatus").textContent =
    latest ? "Data received" : "Waiting for data";

  document.getElementById("recordCount").textContent =
    `${records.length} records`;

  // New category cards
  document.getElementById("childrenCount").textContent =
    totals.Children;

  document.getElementById("menCount").textContent =
    totals.Men;

  document.getElementById("womenCount").textContent =
    totals.Women;

  // Recent visitor records table
  const body = document.getElementById("recordsBody");

  body.innerHTML = "";

  records.slice(-10).reverse().forEach(record => {

    const tr = document.createElement("tr");

    const d = dateValue(record.timestamp);

    const values = [
      record.device,
      record.visitor_count,
      record.category,
      d ? d.toLocaleString() : record.timestamp
    ];

    values.forEach(value => {
      const td = document.createElement("td");

      td.textContent = String(value);

      tr.appendChild(td);
    });

    body.appendChild(tr);
  });

  if (!records.length) {
    body.innerHTML =
      '<tr><td colspan="4" class="empty">No records returned by the API.</td></tr>';
  }

  // Refresh graphs
  drawCharts(records);

  document.getElementById("lastUpdated").textContent =
    new Date().toLocaleTimeString();

  // Connection status
  const status = document.getElementById("connection");

  status.classList.toggle("live", live);

  status.innerHTML = live
    ? "<i></i> AWS API connected"
    : "<i></i> Demo mode";
}

// Fetch data from AWS API
async function loadData() {

  const message = document.getElementById("message");

  if (!apiBaseUrl) {
    render(sampleRecords, false);

    message.textContent =
      "Showing sample data. Configure your AWS API URL.";

    return;
  }

  try {

    const response = await fetch(apiBaseUrl, {
      headers: {
        "Accept": "application/json"
      }
    });

    if (!response.ok) {
      throw new Error(
        `API returned HTTP ${response.status}`
      );
    }

    const data = await response.json();

    const records = normalizeRecords(data);

    render(records, true);

    message.textContent =
      "Connected to AWS API. Dashboard refreshes every 15 seconds.";

  } catch (error) {

    console.error("Dashboard API error:", error);

    render(sampleRecords, false);

    message.textContent =
      `Could not load AWS data: ${error.message}. Showing sample data.`;
  }
}

// Refresh button
document.getElementById("refreshBtn")
  .addEventListener("click", loadData);

// Initial load
loadData();

// Automatic refresh every 15 seconds
setInterval(loadData, 15000);
