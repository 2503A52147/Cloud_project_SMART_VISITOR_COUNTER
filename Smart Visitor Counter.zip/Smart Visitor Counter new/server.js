const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// Existing AWS API Gateway endpoint
const API_BASE_URL = process.env.API_BASE_URL || "https://vshtf2t5xh.execute-api.us-east-1.amazonaws.com/prod/visitors";

app.use(express.static(path.join(__dirname, "public")));

app.get("/config.js", (_req, res) => {
  res.type("application/javascript");
  res.send(
    `window.DASHBOARD_CONFIG = ${JSON.stringify({
      apiBaseUrl: API_BASE_URL
    })};`
  );
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Dashboard running at http://localhost:${PORT}`);
  console.log(`AWS API: ${API_BASE_URL}`);
});
